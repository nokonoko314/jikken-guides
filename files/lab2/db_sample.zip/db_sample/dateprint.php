﻿<?php
header("Cache-Control:no-cache,no-store,must-revalidate,max-age=0");
header("Cache-Control:pre-check=0,post-check=0,false");
header("Pragma:no-cache");	
?>
<html>
<head>
<meta charset="utf-8">
<title>PHP-DB-TEST</title>
</head>
<body>
<H1>PHP-DB-TEST</H1>
<Hr>
ページのキャッシュを更新しないと、表は変わらないことがあるので注意してね。
<Hr>
<Table  border="1">
<?php
#https://qiita.com/tabo_purify/items/2575a58c54e43cd59630
try {
	$pdo = new PDO('mysql:host=localhost;dbname=updatetime;charset=utf8','ktajima','password',
	array(PDO::ATTR_EMULATE_PREPARES => false));
	$stmt = $pdo->prepare("SELECT * FROM clickedtable");
	$stmt->execute();
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		echo '<tr>';
		echo '<td>'.htmlspecialchars($row['time']).'</td>';
		echo '<td>'.htmlspecialchars($row['ip']).'</td>';
		echo '</tr>';
	}
} catch (PDOException $e) {
	exit('データベース接続失敗。'.$e->getMessage());
}
?>
</Table>
<button onclick="location.href='./dateadd.php'">要素を追加</button>
<hr>
</body>
</html>
