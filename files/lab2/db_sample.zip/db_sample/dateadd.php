﻿<html>
<head>
<meta charset="utf-8">
<title>PHP-DB-TEST</title>
</head>
<body>
<H1>PHP-DB-TEST</H1>
<Hr>
<?php
#https://qiita.com/tabo_purify/items/2575a58c54e43cd59630
#create database updatetime;
#create user 'ktajima'@'localhost' identified by 'password';
#grant all on updatetime.* to 'ktajima'@'localhost' identified by 'password';
#CREATE TABLE `updatetime`.`clickedtable` ( `time` DATETIME NOT NULL , `ip` TEXT NOT NULL );
try {
	$pdo = new PDO('mysql:host=localhost;dbname=updatetime;charset=utf8','ktajima','password',
	array(PDO::ATTR_EMULATE_PREPARES => false));
	$stmt = $pdo -> prepare("INSERT INTO clickedtable (time, ip) VALUES (:time, :ip)");
	$stmt->bindParam(':time', date("Y/m/d H:i:s"), PDO::PARAM_STR);
	$stmt->bindValue(':ip', $_SERVER["REMOTE_ADDR"], PDO::PARAM_STR);
	$stmt->execute();
    echo '日付を追加したよ';
} catch (PDOException $e) {
	exit('データベース接続失敗。'.$e->getMessage());
}
?>
<hr>
<a href="./dateprint.php">[戻る]</a>
</body>
</html>
